<?php $__env->startSection('title'); ?> Buat Postingan Lowongan <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="card card-primary">
<form action="<?php echo e(route('postings.store')); ?>" method="POST">
    <?php echo csrf_field(); ?>
<div class="card-body">
    <div class="form-group">
        <label>Judul</label>
        <input type="text" name="judul" id="judul" class="form-control">
    </div>
    <div class="form-group">
        <label>Deskripsi</label>
        <textarea name="deskripsi" class="form-control summernote"></textarea>
    </div>
    <div class="form-group">
        <label>Tempat</label>
        <select class="form-control" name="tempat">
            <option value="Hydromedical Canggu">Hydromedical Canggu</option>
            <option value="Hydro Batubelig Baru">Hydromedical Batubelig Baru</option>
            <option value="Hydro Batubelig Lama">Hydromedical Batubelig Lama</option>
            <option value="Unicare Uluwatu">Unicare Uluwatu</option>
            <option value="Unicare Ubud">Unicare Ubud</option>
            <option value="Unicare Kupang">Unicare Kupang</option>
            <option value="Head Office">Head Office Hydro & Unicare</option>
            <option value="Drive-Thru Kuta">Drive Thru Kuta</option>
            <option value="Drive-Thru Ramada">Drive Thru Ramada</option>
        </select>
    </div>
    <div class="form-group">
        <label>Kategori</label>
        <input type="text" class="form-control" name="kategori">
    </div>
    <div class="form-group">
        <label for="photo" name="photo">Gambar</label>
        <input class="form-control" type="file" name="photo" id="photo">
    </div>
</div>
<div class="card-footer">
    <a href="<?php echo e(route('postings.index')); ?>" class="btn bg-gradient-secondary">Kembali</a>
    <button type="submit" class="btn bg-gradient-success">Buat Posting Lowongan</button>
</div>
</div>
</form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\simaka\resources\views/postings/create.blade.php ENDPATH**/ ?>