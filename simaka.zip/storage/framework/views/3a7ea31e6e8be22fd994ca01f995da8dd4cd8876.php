<?php $__env->startSection('title'); ?> Tambah Data Karyawan <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="card card-primary">
    <!-- /.card-header -->
    <form action="<?php echo e(route('karyawans.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="card-body">
            <div class="form-group">
                <label>Nama Karyawan</label>
                <input type="text" name="name" class="form-control" placeholder="ex : Rahmat Letsgo">
            </div>
            <div class="row">
                <div class="col-sm-6">
                    <!-- text input -->
                    <div class="form-group">
                        <label>Tempat, Tanggal Lahir</label>
                        <input type="text" name="ttl" class="form-control" placeholder="Tempat, DD/MM/YYYY">
                    </div>
                </div>
                <div class="col-sm-6">
                    <!-- text input -->
                    <div class="form-group">
                        <label>Jabatan</label>
                        <select class="form-control" name="posisi">
                            <option value="Dokter" <?php echo e($karyawan->posisi === 'Dokter' ? 'selected' : ''); ?>>Dokter</option>
                            <option value="Perawat" <?php echo e($karyawan->posisi === 'Perawat' ? 'selected' : ''); ?>>Perawat</option>
                            <option value="Finance" <?php echo e($karyawan->posisi === 'Finance' ? 'selected' : ''); ?>>Finance</option>
                            <option value="Cleaning Service" <?php echo e($karyawan->posisi === 'Cleaning Service' ? 'selected' : ''); ?>>Cleaning Service</option>
                            <option value="Call Center" <?php echo e($karyawan->posisi === 'Call Center' ? 'selected' : ''); ?>>Call Center</option>
                            <option value="Marketing" <?php echo e($karyawan->posisi === 'Marketing' ? 'selected' : ''); ?>>Marketing</option>
                            <option value="Technician" <?php echo e($karyawan->posisi === 'Technician' ? 'selected' : ''); ?>>Teknisi</option>
                            <option value="Designer Grafis" <?php echo e($karyawan->posisi === 'Designer Grafis' ? 'selected' : ''); ?>>Designer Grafis</option>
                            <option value="Programmer" <?php echo e($karyawan->posisi === 'Programmer' ? 'selected' : ''); ?>>Programmer</option>
                        </select>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-6">
                    <!-- textarea -->
                    <div class="form-group">
                        <label>Jenis Kelamin</label>
                        <select class="form-control" name="gender">
                            <option value="Laki-Laki" <?php echo e($karyawan->gender === 'Laki-Laki' ? 'selected' : ''); ?>>Laki-Laki</option>
                            <option value="Perempuan" <?php echo e($karyawan->gender === 'Perempuan' ? 'selected' : ''); ?>>Perempuan</option>
                        </select>
                    </div>
                </div>
                <div class="col-sm-6">
                    <!-- textarea -->
                    <div class="form-group">
                        <label>Posisi</label>
                        <select class="form-control" name="tempat">
                            <option value="Hydro Canggu <?php echo e($karyawan->tempat === 'Hydro Canggu' ? 'selected' : ''); ?>">Hydromedical Canggu</option>
                            <option value="Hydro Batubelig Baru <?php echo e($karyawan->tempat === 'Hydro Batubelig Baru' ? 'selected' : ''); ?>">Hydromedical Batubelig Baru</option>
                            <option value="Unicare Uluwatu <?php echo e($karyawan->tempat === 'Unicare Uluwatu' ? 'selected' : ''); ?>">Unicare Uluwatu</option>
                            <option value="Unicare Ubud <?php echo e($karyawan->tempat === 'Unicare Ubud' ? 'selected' : ''); ?>">Unicare Ubud</option>
                            <option value="Head Office <?php echo e($karyawan->tempat === 'Head Office' ? 'selected' : ''); ?>">Head Office Hydro & Unicare </option>
                        </select>
                    </div>
                </div>
            </div>
            <div class="form-group">
                <label>Alamat</label>
                <input type="text" name="alamat" class="form-control" placeholder="ex: Los Angeles, CA">
            </div>
        </div>
        <div class="card-footer">
            <a href="<?php echo e(route('karyawans.index')); ?>" class="btn btn-secondary">Kembali</a>
            <button type="submit" class="btn bg-gradient-primary">Buat Data Pasien</button>
        </div>
        <!-- input states -->
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\simaka\resources\views/karyawans/edit.blade.php ENDPATH**/ ?>