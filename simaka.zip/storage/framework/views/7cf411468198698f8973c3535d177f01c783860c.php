<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>
      Your data is successfully delivered
</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Open+Sans&display=swap" rel="stylesheet">

  <link rel="stylesheet" href="<?php echo e(asset('assets/plugins/fontawesome-free/css/all.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('assets/css/adminlte.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('assets/plugins/sweetalert2/sweetalert2.min.css')); ?>">

</head>
<body class="register-page">
    <img src="<?php echo e(asset('assets-dj/assets/img/oKUuTF4.png')); ?>" width="300px" height="100px"> <br />
    <div class="register-box">
        <div class="card card-outline card-primary">
            <div class="card-header text-center">
                <a href="https://www.unicare-clinic.com" class="h1">
                    Successfully Delivered
                </a>
            </div>
            <div class="card-body">
                <p>
                    You're now have one step ahead to be our Family
                </p>
                <p>
                    Pastikan nomor whatsapp anda sudah aktif.
                </p>
                <p>
                    Agar kami bisa menghubungi anda untuk interview :)
                </p>
                <div class="social-auth-links text-center mt-2 mb-3">
                    <a href="https://www.unicare-clinic.com" class="btn btn-block btn-primary">
                        <i class="fas fa-home mr-2"></i>
                        Kembali
                    </a>
                    <a href="/" class="btn btn-block btn-success">
                        <i class="fas fa-undo mr-2"></i>
                        Daftar Lagi
                    </a>
                </div>
            </div>
        </div>
    </div>
</body>
<!-- jQuery -->
<script src="<?php echo e(asset('assets/plugins/jquery/jquery.min.js')); ?>"></script>
<!-- Bootstrap 4 -->
<script src="<?php echo e(asset('assets/plugins/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
<!-- AdminLTE App -->
<script src="<?php echo e(asset('assets/js/adminlte.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/script.js')); ?>"></script>
<script src="<?php echo e(asset('assets/plugins/sweetalert2/sweetalert2.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/plugins/dropzone/dropzone.js')); ?>"></script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\simaka\resources\views/validations/validate.blade.php ENDPATH**/ ?>