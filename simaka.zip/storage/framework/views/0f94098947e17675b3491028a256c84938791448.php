<?php $__env->startSection('title'); ?> Index Postingan Lowongan <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header">
      <?php echo $__env->make('partials.flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <div class="card-tools">
          <div class="input-group input-group-sm" style="width: 150px;">
              <form action="<?php echo e(route('registerkaryawans.index')); ?>" method="GET" role="search">
              <input type="text" name="search" class="form-control float-right" placeholder="Cari">
              <div class="input-group-append">
                <button type="submit" class="btn btn-default">
                  <i class="fas fa-search"></i>
                </button>
              </div>
          </form>
            </div>
      </div>
    </div>
    <!-- /.card-header -->
    <div class="card-body table-responsive p-0">
      <table class="table table-bordered table-hover text-nowrap">
        <thead>
          <tr>
            <th>#</th>
            <th>Judul Postingan</th>
            <th>Deskripsi Singkat</th>
            <th>Requirements</th>
            <th>Kategori</th>
            <th>Photo</th>
            <th>Actions</th>
          </tr>
        </thead>
    <tbody>
          <?php $__empty_1 = true; $__currentLoopData = $postings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pst): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
          <tr>
            <td><?php echo e($pst->id); ?></td>
            <td><?php echo e($pst->judul); ?></td>
            <td><?php echo e($pst->deskripsi); ?></td>
            <td><?php echo e($pst->tempat); ?></td>
            <td><?php echo e($pst->requirements); ?></td>
            <td><?php echo e($pst->kategori); ?></td>
            <td><?php echo e($pst->photo); ?></td>
            <form action="<?php echo e(route('registerkaryawans.destroy', $rk->id )); ?>" method="POST" id="form">
              <?php echo csrf_field(); ?>
              <?php echo method_field('DELETE'); ?>
              <td>
                <div class="btn-group">
                  <a href="<?php echo e(route('postings.show', $pst->judul)); ?>" type="button" class="btn btn-primary">
                    <i class="fas fa-search"></i>
                    <a href="<?php echo e(route('postings.edit', $rk->judul )); ?>" type="button" class="btn btn-warning"><i class="fas fa-edit"></i></a>
                    <button type="submit" class="btn btn-danger delete-button">
                      <i class="fas fa-trash"></i>
                    </button>
                  </div>
                </td>
              </form>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr class="expandable-body">
              <td colspan="8">
                <p align="center">
                    Postingan belum ada, atau kamu belum buat :(
                </p>
              </td>
            </tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
      <!-- /.card-body -->
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\simaka\resources\views/postings/index.blade.php ENDPATH**/ ?>