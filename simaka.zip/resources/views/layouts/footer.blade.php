<footer class="main-footer">
    <!-- To the right -->
    <div class="float-right d-none d-sm-inline">
      Full Version
    </div>
    <!-- Default to the left -->
    <strong>&copy; 2021 Syntak Team by Unicare </strong> | Built with 💖 by <a href="https://twitter.com/@oggiesutrisna">Oggie Sutrisna</a>. All rights reserved.
  </footer>
