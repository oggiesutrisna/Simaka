<?php $__env->startSection('title'); ?> Data Calon Karyawan <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="card">
  <div class="card-header">
    <?php echo $__env->make('partials.flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  </div>
  <!-- /.card-header -->
  <div class="card-body table-responsive p-0">
    <table class="table table-bordered table-hover text-nowrap">
      <thead>
        <tr>
          <th>#</th>
          <th>Nama Karyawan</th>
          <th>Date Of Birth</th>
          <th>Email</th>
          <th>Penempatan</th>
          <th>Status</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $registerkaryawans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr>
          <td><?php echo e($rk->id); ?></td>
          <td><?php echo e($rk->nama); ?></td>
          <td><?php echo e($rk->ttl); ?></td>
          <td><?php echo e($rk->email); ?> </td>
          <td><?php echo e($rk->tempat); ?></td>
          <td>
              <span class="badge badge-<?php echo e($rk->diterima === 'belum diterima' ? 'danger' : 'success'); ?> px-3 py-3" data-toggle="tooltip" data-placement="top" title="<?php echo e($rk->diterima); ?>">
                <i class="fas <?php echo e($rk->diterima === 'belum diterima' ? 'fa-minus-circle' : 'fa-minus-circle'); ?>">
                </i>
            </span>
          </td>
          <form action="<?php echo e(route('registerkaryawans.destroy', $rk->id )); ?>" method="POST" id="form">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
            <td>
              <div class="btn-group">
                <a href="<?php echo e(route('registerkaryawans.show', $rk->id)); ?>" type="button" class="btn btn-primary">
                  <i class="fas fa-search"></i></a>
                  <button type="submit" class="btn btn-danger delete-button">
                    <i class="fas fa-trash"></i>
                  </button>
                </div>
              </td>
            </form>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
          <tr class="expandable-body">
            <td colspan="8">
              <p align="center">
                Data pelamar belum ada, mungkin belum dibuat atau calon karyawan belum ada yang tertarik
              </p>
            </td>
          </tr>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
    <!-- /.card-body -->
  </div>
  <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\simaka\resources\views/registerkaryawans/index.blade.php ENDPATH**/ ?>