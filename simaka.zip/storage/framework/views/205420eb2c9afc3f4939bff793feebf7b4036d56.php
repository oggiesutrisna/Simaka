<?php $__env->startSection('title'); ?> Edit Calon Karyawan <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="card card-primary">
    <div class="card-header">
        <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
    </div>
    <form action="<?php echo e(route('registerkaryawans.update', $registerkaryawan->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="card-body">
            <div class="row">
                <div class="col-sm-6">
                    <div class="form-group">
                        <label>Email</label>
                        <input type="text" name="email" value="<?php echo e($registerkaryawan->email); ?>" class="form-control" disabled>
                    </div>
                </div>
                <div class="col-sm-6">
                    <div class="form-group">
                        <label>Nama Karyawan</label>
                        <input type="text" name="nama" value="<?php echo e($registerkaryawan->nama); ?>" class="form-control" disabled>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-6">
                    <div class="form-group">
                        <label>Tempat, Tanggal Lahir</label>
                        <input type="text" name="ttl" class="form-control" placeholder="Tempat, DD/MM/YYYY" value="<?php echo e($registerkaryawan->ttl); ?>" disabled>
                    </div>
                </div>
                <div class="col-sm-6">
                    <div class="form-group">
                        <label>Posisi Melamar</label>
                        <select class="form-control" name="posisi" disabled>
                            <option value="Dokter <?php echo e($registerkaryawan->posisi === 'Dokter' ? 'selected' : ''); ?>">Dokter</option>
                            <option value="Perawat" <?php echo e($registerkaryawan->posisi === 'Perawat' ? 'selected' : ''); ?>>Perawat</option>
                            <option value="Finance" <?php echo e($registerkaryawan->posisi === 'Finance' ? 'selected' : ''); ?>>Finance</option>
                            <option value="Cleaning Service" <?php echo e($registerkaryawan->posisi === 'Cleaning Service' ? 'selected' : ''); ?>>Cleaning Service</option>
                            <option value="Call Center" <?php echo e($registerkaryawan->posisi === 'Call Center' ? 'selected' : ''); ?>>Call Center</option>
                            <option value="Marketing" <?php echo e($registerkaryawan->posisi === 'Marketing' ? 'selected' : ''); ?>>Marketing</option>
                            <option value="Technician" <?php echo e($registerkaryawan->posisi === 'Technician' ? 'selected' : ''); ?>>Teknisi</option>
                            <option value="Designer Grafis" <?php echo e($registerkaryawan->posisi === 'Designer Grafis' ? 'selected' : ''); ?>>Designer Grafis</option>
                            <option value="Programmer" <?php echo e($registerkaryawan->posisi === 'Programmer' ? 'selected' : ''); ?>>Programmer</option>
                        </select>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-6">
                    <div class="form-group">
                        <label>Jenis Kelamin</label>
                        <select class="form-control" name="gender" disabled>
                            <option value="Laki-Laki" <?php echo e($registerkaryawan->gender === 'Laki-Laki' ? 'selected' : ''); ?>>Laki-Laki</option>
                            <option value="Perempuan" <?php echo e($registerkaryawan->posisi === 'Dokter' ? 'selected' : ''); ?> >Perempuan</option>
                        </select>
                    </div>
                </div>
                <div class="col-sm-6">
                    <div class="form-group">
                        <label>No Telepon / No Whatsapp Aktif</label>
                        <input type="text" value="<?php echo e($registerkaryawan->notelp); ?>" name="notelp" class="form-control" placeholder="Nomor Whatsapp Aktif" disabled>
                        <button type="button" class="btn btn-default" data-toggle="modal" data-target="#modal-whatsapp">
                            Whatsapp
                          </button>
                    </div>
                </div>
                <div class="col-sm-6">
                    <div class="form-group">
                        <label>Pendidikan Terakhir</label>
                        <select class="form-control" name="pend_terakhir" id="pend_terakhir" disabled>
                            <option value="SMP" <?php echo e($registerkaryawan->pend_terakhir === 'SMP' ? 'selected' : ''); ?>> SMP </option>
                            <option value="SMA" <?php echo e($registerkaryawan->pend_terakhir === 'SMA' ? 'selected' : ''); ?>> SMA </option>
                            <option value="SMK"<?php echo e($registerkaryawan->pend_terakhir === 'SMK' ? 'selected' : ''); ?>> SMK </option>
                            <option value="Diploma 1" <?php echo e($registerkaryawan->pend_terakhir === 'Diploma 1' ? 'selected' : ''); ?>> Diploma 1 </option>
                            <option value="Diploma 2" <?php echo e($registerkaryawan->pend_terakhir === 'Diploma 2' ? 'selected' : ''); ?>> Diploma 2 </option>
                            <option value="Diploma 3" <?php echo e($registerkaryawan->pend_terakhir === 'Diploma 3' ? 'selected' : ''); ?>> Diploma 3 </option>
                            <option value="Sarjana 1" <?php echo e($registerkaryawan->pend_terakhir === 'Sarjana 1' ? 'selected' : ''); ?>> Sarjana 1 </option>
                            <option value="Sarjana 2" <?php echo e($registerkaryawan->pend_terakhir === 'Sarjana 2' ? 'selected' : ''); ?>> Sarjana 2 </option>
                            <option value="Sarjana 3" <?php echo e($registerkaryawan->pend_terakhir === 'Sarjana 3' ? 'selected' : ''); ?>> Sarjana 3 </option>
                            <option value="Dokter" <?php echo e($registerkaryawan->pend_terakhir === 'Dokter' ? 'selected' : ''); ?>> Dokter </option>
                            <option value="Professor" <?php echo e($registerkaryawan->pend_terakhir === 'Professor' ? 'selected' : ''); ?>> Professor </option>
                            <option value="Doktor" <?php echo e($registerkaryawan->pend_terakhir === 'Doktor' ? 'selected' : ''); ?>> Doktor </option>
                        </select>
                    </div>
                </div>
                <div class="col-sm-6">
                    <div class="form-group">
                        <label>Rencana Penempatan</label>
                        <select class="form-control" name="tempat">
                            <option value="Head Office">Head Office Hydro & Unicare </option>
                            <option value="Hydro Canggu">Klinik Hydromedical Canggu</option>
                            <option value="Hydro Batubelig Baru">Klinik Hydromedical Batubelig Baru</option>
                            <option value="Hydro Batubelig Lama">Klinik Unicare Tambolaka</option>
                            <option value="Unicare Uluwatu">Klinik Unicare Uluwatu</option>
                            <option value="Unicare Ubud">Klinik Unicare Ubud</option>
                            <option value="Unicare Tambolaka">Klinik Unicare Tambolaka</option>
                            <option value="Unicare Kupang">Klinik Unicare Kupang</option>
                            <option value="Drive-Thru Central Parkir Kuta">[Drive Thru] Central Parkir Kuta </option>
                            <option value="Unicare Ibis Petitenget">[Drive Thru] Unicare Drive Thru Ibis Petitenget</option>
                            <option value="Unicare New Kuta Golf">[Drive Thru] Unicare Drive Thru New Kuta Golf</option>
                            <option value="Unicare Villa Jerami">[Drive Thru] Unicare Drive Thru Villa Jerami</option>
                            <option value="Unicare Central Parkir">[Drive Thru] Unicare Drive Thru Central Parkir</option>
                            <option value="Unicare Drive Thru BSMC">[Drive Thru] Drive Thru BSMC </option>
                            <option value="Unicare Drive Thru CHIS">[Drive Thru] Drive Thru CHIS </option>
                            <option value="Unicare Drive Thru Padang Sambian">[Drive Thru] Drive Thru Padang Sambian </option>
                        </select>
                    </div>
                </div>
                <div class="col-sm-6">
                    <div class="form-group">
                        <label>Dapat Informasi</label>
                        <input type="text" name="dapatinformasi" value="<?php echo e($registerkaryawan->dapatinformasi); ?>" class="form-control" disabled>
                    </div>
                </div>
                <div class="col-sm-6">
                    <div class="form-group">
                        <label>Diterima ?</label>
                        <select name="diterima" value="diterima" class="form-control <?php if($errors->has('diterima')): ?> is-invalid <?php endif; ?>">
                            <option value="Belum Diterima" selected>Belum Diterima</option>
                            <option value="Diterima">Diterima</option>
                            <option value="Tidak Diterima">Tidak Diterima</option>
                        </select>
                    </div>
                </div>
                <div class="col-sm-6">
                    <div class="form-group">
                        <label>Jadwal Interview</label>
                        <input type="date" value="<?php echo e($registerkaryawan->jadwal); ?>" name="jadwal" class="form-control <?php if($errors->has('date')): ?> is-invalid <?php endif; ?>">
                    </div>
                </div>
                <div class="col-sm-6">
                    <div class="form-group">
                        <div class="form-group">
                            <label>Alamat Lengkap</label>
                            <input type="text" name="alamat" value="<?php echo e($registerkaryawan->alamat); ?>" class="form-control" placeholder="ex: Hehe" disabled>
                        </div>
                    </div>
                </div>
            </div>
            <div class="form-group">
                <label>Alasan diterima/tidak diterima</label>
                <textarea type="text" value="<?php echo e($registerkaryawan->alasan); ?>" name="alasan" class="form-control <?php if($errors->has('alasan')): ?> is-invalid <?php endif; ?>" rows="4" cols="50"></textarea>
            </div>
        </div>
        <div class="card-footer">
            <a href="<?php echo e(route('registerkaryawans.index')); ?>" class="btn btn-secondary">Kembali</a>
            <button type="submit" class="btn bg-gradient-primary">Update Data Calon Karyawan</button>
        </div>
</div>

<div class="modal fade" id="modal-whatsapp" style="display: none;" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h4 class="modal-title">Chat Generator</h4>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">×</span>
          </button>
        </div>
        <div class="modal-body">
            <label>
                Salin quote dibawah ini
            </label>
          <textarea cols="54" rows="10">Selamat pagi, apakah benar dengan nama, <?php echo e($registerkaryawan->nama); ?>? Perkenalkan, saya Ari dari HRD di Unicare Clinic menginformasikan bahwa anda akan diinterview pada tanggal <?php echo e($registerkaryawan->jadwal); ?>, untuk mengkonfirmasi bisa bilang HADIR. Terimakasih.
          Regards
          -Ari Darma,
          Lead Human Resource Department @ Unicare Clinic-
          </textarea>
          <div class="form-group">
              <label>
                  Nomor Whatsapp Calon Kandidat
              </label>
              <input type="text" class="form-control form-control-border" id="exampleInputBorder" value="<?php echo e($registerkaryawan->notelp); ?>" placeholder="../../../" disabled>
          </div>
        </div>
        <div class="modal-footer justify-content-between">
          <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
          <a href="https://api.whatsapp.com/send?phone=<?php echo e($registerkaryawan->notelp); ?>" class="btn btn-success">Kirim Pesan</a>
        </div>
      </div>
      <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
  </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\simaka\resources\views/registerkaryawans/edit.blade.php ENDPATH**/ ?>