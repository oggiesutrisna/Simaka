<?php $__env->startSection('title'); ?> Data Karyawan <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header">
        <?php echo $__env->make('partials.flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <!-- /.card-header -->
    <div class="card-body">
      <table class="table table-bordered">
        <thead>
          <tr>
            <th>#</th>
            <th>Nama Karyawan</th>
            <th>Tempat, Tanggal Lahir</th>
            <th>Jenis Kelamin</th>
            <th>Nomor Whatsapp Aktif</th>
            <th>Pendidikan Terakhir</th>
            <th>Posisi</th>
            <th>Alamat</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $karyawans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $karyawan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
          <tr>
              <td><?php echo e($karyawan->id); ?></td>
              <td><?php echo e($karyawan->name); ?></td>
              <td><?php echo e($karyawan->ttl); ?></td>
              <td><?php echo e($karyawan->gender); ?></td>
              <td><?php echo e($karyawan->notelp); ?></td>
              <td><?php echo e($karyawan->pend_terakhir); ?></td>
              <td><?php echo e($karyawan->posisi); ?></td>
              <td><?php echo e($karyawan->alamat); ?></td>
              <form action="<?php echo e(route('karyawans.destroy', $karyawan->id )); ?>" method="POST" id="form">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
              <td>
                  <div class="btn-group-vertical">
                      <a href="<?php echo e(route('karyawans.show', $karyawan->id )); ?>" type="button" class="btn btn-primary">
                        <i class="fas fa-search"></i>
                        <a href="<?php echo e(route('karyawans.edit', $karyawan->id )); ?>" type="button" class="btn btn-warning"><i class="fas fa-edit"></i></a>
                        <button type="submit" class="btn btn-danger delete-button">
                            <i class="fas fa-trash"></i>
                        </button>
                  </div>
                </td>
              </form>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
          <tr class="expandable-body">
            <td colspan="11">
              <p align="center">
                Data Karyawan belum ada, mungkin belum dibuat hehe.
            </p>
            </td>
          </tr>
        <?php endif; ?>
        </tbody>
      </table>
    </div>
    <!-- /.card-body -->
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\simaka\resources\views/karyawans/index.blade.php ENDPATH**/ ?>